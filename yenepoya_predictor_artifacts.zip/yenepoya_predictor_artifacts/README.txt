Yenepoya MD Medicine Predictor — Canonical Dataset & Ontology (auto-generated)

Files:
1) yenepoya_master_questions_2006_2025.csv
   - Unified question bank across uploaded archives (deduped).
   - Includes holdout-year 2025 rows (for evaluation), clearly filter year<2025 for training.

2) yenepoya_master_questions_train_upto_2024.csv
   - Convenience slice: year<2025 only.

3) leakage_audit_log.csv
   - Sources/rows excluded from training to avoid 2025 leakage.

4) harrison_index_ontology.csv
   - Harrison Index JSONL converted to a flat ontology table with a coarse domain label.

5) question_to_harrison_tags.csv
   - Each question mapped to 0–5 Harrison index terms using char-ngram TF-IDF nearest neighbors.
   - Threshold used: cosine similarity >= 0.28.
   - 'templates_str' is regex-derived question-template labels.

6) topic_table_from_exam_matches.csv
   - Only the Harrison terms that were matched to any historical question (pragmatic topic catalog starter).
